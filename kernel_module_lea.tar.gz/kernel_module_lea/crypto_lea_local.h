#ifndef CRYPTO_LEA_LOCAL_H
#define CRYPTO_LEA_LOCAL_H

#include "crypto_lea.h"
#include <linux/types.h>
#include <linux/string.h>

void __crypto_lea_encrypt(const void *ctx, u8 *dst, const u8 *src);
void __crypto_lea_decrypt(const void *ctx, u8 *dst, const u8 *src);

#define SIMD_KEY_ALIGN 16
#define SIMD_ALIGN_ATTR __attribute__((__aligned__(SIMD_KEY_ALIGN)))

struct lea_xts_ctx {
  u8 raw_crypt_ctx[sizeof(struct crypto_lea_ctx)] SIMD_ALIGN_ATTR;
  u8 raw_tweak_ctx[sizeof(struct crypto_lea_ctx)] SIMD_ALIGN_ATTR;
};

#define LEA_AVX2_PARALLEL_BLOCKS 8
#define LEA_SSE2_PARALLEL_BLOCKS 4

#endif