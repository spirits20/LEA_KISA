#ifndef _CRYPTO_LEA_H
#define _CRYPTO_LEA_H

#include <linux/crypto.h>
#include <linux/types.h>

#define LEA_MIN_KEY_SIZE 16
#define LEA_MAX_KEY_SIZE 32
#define LEA_KEYSIZE_128 16
#define LEA_KEYSIZE_192 24
#define LEA_KEYSIZE_256 32
#define LEA_BLOCK_SIZE 16
#define LEA_ROUND_CNT(key_len) ((key_len >> 1) + 16)

#define LEA_MAX_KEYLENGTH_U32 (LEA_ROUND_CNT(LEA_MAX_KEY_SIZE) * 6)
#define LEA_MAX_KEYLENGTH (LEA_MAX_KEYLENGTH * sizeof(u32))

struct crypto_lea_ctx {
  u32 rk[LEA_MAX_KEYLENGTH_U32];
  u32 round;
};

static inline int lea_check_keylen(u32 keylen) {
  switch (keylen) {
  case LEA_KEYSIZE_128:
  case LEA_KEYSIZE_192:
  case LEA_KEYSIZE_256:
    break;
  default:
    return -EINVAL;
  }

  return 0;
}

extern const u32 lea_delta[8][36] ____cacheline_aligned;

int crypto_lea_set_key(struct crypto_tfm *tfm, const u8 *in_key, u32 key_len);
int _crypto_lea_set_key(struct crypto_lea_ctx *ctx, const u8 *in_key,
                        u32 key_len);
#endif