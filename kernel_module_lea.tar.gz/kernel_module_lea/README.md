# Linux LEA 암호 모듈
- 버전: 1.0

Linux 커널 내 Crypto API에 LEA 암호 알고리즘을 사용할 수 있도록 제공하는 모듈입니다.

C 언어로 구성된 범용 LEA 암호 모듈 `crypto_lea.ko`와 AVX2, movbe, SSE2 명령어를 포함하여 구성된 고속 x86-64 LEA 암호 모듈 `crypto_lea_simd.ko` 모듈로 이루어져 있습니다.

본 모듈은 Linux 커널 라이선스를 따라 GPL-2.0-or-later 라이선스를 따릅니다.

## 구현 대상

x86-64(64비트), x86(32비트) 각각 구현되어 있습니다.

### 64비트 구현
- 4블록 ECB 암/복호화: SSE2
- 8블록 ECB 암/복호화: AVX2
- 4블록 CBC 복호화: SSE2
- 8블록 CBC 복호화: AVX2
- 4블록 CTR 암호화: SSE2, SSE2+MOVBE
- 8블록 CTR 암호화: AVX2+MOVBE
- 4블록 XTS 암/복호화: SSE2
- 8블록 XTS 암/복호화: AVX2

GCM 모드는 리눅스 Crypto API내에 `gcm-base(ctr(lea), ghash)`를 이용합니다.

### 32비트 구현
- 4블록 ECB 암/복호화: SSE2
- 8블록 ECB 암/복호화: AVX2
- 4블록 CBC 복호화: SSE2
- 4블록 CTR 암호화: SSE2, SSE2+MOVBE
- 8블록 CTR 암호화: AVX2+MOVBE

GCM 모드는 리눅스 Crypto API내에 `gcm-base(ctr(lea), ghash)`를 이용합니다.

XTS 모드는 Crypto API내에 `xts(ecb(lea))`를 이용합니다.

## 빌드 절차

Debian, Ubuntu를 기준으로 설명합니다.

다음 명령어를 통해 의존 패키지를 설치합니다.

```sh
sudo apt install build-essential dpkg-dev linux-headers-$(uname -r)
```

`linux-headers`는 LEA 암호 모듈을 설치하고자 하는 리눅스의 버전과 일치해야하며, 위 명령어는 빌드 환경과 적용 리눅스 버전이 일치할때를 기준으로 한 명령어 입니다.

이후 다음 명령어를 통해 컴파일하고, 모듈을 적재할 수 있습니다.

```sh
make
sudo insmod crypto_lea.ko
sudo insmod crypto_lea_simd.ko
```

필요하다면 `make install` 등의 명령으로 실제 모듈을 설치하고, 부트로더에 커널 모듈을 등록하는 작업을 같이 수행할 수 있습니다.

## 파일 안내

### `Makefile`
리눅스 커널 모듈 생성을 위한 Helper makefile입니다.

### `Kbuild`
실제 리눅스 커널 모듈 생성 Makefile 구성 파일입니다.

### `crypto_lea.c`, `.h`
C언어로 구현된 범용 LEA 암호화 구현입니다.

### `crypto_lea_simd_glue.c`, `crypto_lea_local.h`
`crypto_lea_simd` 모듈 구동 코드입니다.

Crypto API 요청에 따라 Assembly 구현을 호출하여 암/복호화합니다.

### `crypto_lea_{sse2,avx2}-asm.h`
SSE2, AVX2 암/복호화에 필요한 공용 코드입니다.

### `crypto_lea_util_{x64,x86}-asm.h`
x86-64, x86 암/복호화에 필요한 공용 코드입니다.

### `crypto_lea_{sse2,avx2}_{i586,x86_64}-asm.S`
x86-64, x86 및 SSE2, AVX2 조합에 따른 실제 어셈블리 구현입니다.

### `ecb_cbc_helpers.h`
ECB, CBC 호출용 헬퍼 코드입니다. Linux 커널 코드의 `arch/x86/crypto/ecb_cbc_helpers.h`와 동일한 파일입니다. 

### `cleanse_compile_command.sh`

`clangd`를 이용한 개발 환경을 구성할 때 `gcc` 전용 컴파일 플래그를 제거하는데 사용됩니다.

## 테스트 코드

구현물이 올바르게 빌드 되었는지 확인하기 위해 `crypto_lea_test` 모듈을 별도로 제공하고 있습니다.

해당 모듈에서 기본적인 커널 내 암호화 호출을 확인할 수 있습니다.

## 개발/수정 시 안내 사항

본 코드는 Visual Studio Code에서 `clangd` 확장을 이용하여 개발되었습니다.
본 모듈에 암호 운영 모드를 추가하는 등의 개선/수정 작업이 필요할 수 있으며, 다음을 명령을 통해 동일한 구성을 가질 수 있습니다.

```sh
#clangd, bear 필요
make clean
bear -- make
./cleanse_compile_comand.sh
```

Ubuntu 22.04.1 기준으로 `clangd`에서 별도 에러 메시지 없이 `bear` 실행을 통해 생성 된 `compile_command.json` 파일이 정리됩니다.

clang, gcc 버전에 따라 지워야할 flag가 달라 `cleanse_compile_comand.sh`의 추가 수정이 필요할 수 있습니다.

## 변경 사항
### 1.0 (2023-03-06)
초기 릴리즈