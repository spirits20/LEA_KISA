#include <asm-generic/unaligned.h>
#include <crypto/algapi.h>
#include <crypto/ctr.h>
#include <crypto/internal/simd.h>
#include <crypto/scatterwalk.h>
#include <crypto/skcipher.h>
#include <linux/err.h>
#include <linux/module.h>
#include <linux/types.h>

#include "crypto_lea.h"
#include "crypto_lea_local.h"
#include "ecb_cbc_helpers.h"
#include <asm/simd.h>
#include <crypto/internal/skcipher.h>

asmlinkage void lea_ecb_enc_8way(const void *ctx, u8 *dst, const u8 *src);
asmlinkage void lea_ecb_dec_8way(const void *ctx, u8 *dst, const u8 *src);
asmlinkage void lea_ecb_enc_4way(const void *ctx, u8 *dst, const u8 *src);
asmlinkage void lea_ecb_dec_4way(const void *ctx, u8 *dst, const u8 *src);

#if defined(__x86_64__)
asmlinkage void lea_cbc_dec_8way(const void *ctx, u8 *dst, const u8 *src);
#endif
asmlinkage void lea_cbc_dec_4way(const void *ctx, u8 *dst, const u8 *src);

asmlinkage void lea_ctr_enc_4way(const void *ctx, u8 *dst, const u8 *src,
                                 u8 *ctr);
asmlinkage void lea_ctr_enc_4way_no_movbe(const void *ctx, u8 *dst,
                                          const u8 *src, u8 *ctr);
asmlinkage void lea_ctr_enc_8way(const void *ctx, u8 *dst, const u8 *src,
                                 u8 *ctr, u8 *buffer);

#if defined(__x86_64__)
asmlinkage void lea_xts_enc_8way(const void *ctx, u8 *dst, const u8 *src,
                                 u8 *tweak);
asmlinkage void lea_xts_dec_8way(const void *ctx, u8 *dst, const u8 *src,
                                 u8 *tweak);
asmlinkage void lea_xts_enc_4way(const void *ctx, u8 *dst, const u8 *src,
                                 u8 *tweak);
asmlinkage void lea_xts_dec_4way(const void *ctx, u8 *dst, const u8 *src,
                                 u8 *tweak);
asmlinkage void lea_xts_next_tweak_sse2(u8 *tweak_out, const u8 *tweak_in);
asmlinkage void lea_xts_xor_1block(u8 *dst, const u8 *src, const u8 *src2);
#endif

static int ecb_encrypt_8way(struct skcipher_request *req) {
  ECB_WALK_START(req, LEA_BLOCK_SIZE, LEA_SSE2_PARALLEL_BLOCKS);
  ECB_BLOCK(LEA_AVX2_PARALLEL_BLOCKS, lea_ecb_enc_8way);
  ECB_BLOCK(LEA_SSE2_PARALLEL_BLOCKS, lea_ecb_enc_4way);
  ECB_BLOCK(1, __crypto_lea_encrypt);
  ECB_WALK_END();
}

static int ecb_decrypt_8way(struct skcipher_request *req) {
  ECB_WALK_START(req, LEA_BLOCK_SIZE, LEA_SSE2_PARALLEL_BLOCKS);
  ECB_BLOCK(LEA_AVX2_PARALLEL_BLOCKS, lea_ecb_dec_8way);
  ECB_BLOCK(LEA_SSE2_PARALLEL_BLOCKS, lea_ecb_dec_4way);
  ECB_BLOCK(1, __crypto_lea_decrypt);
  ECB_WALK_END();
}

static int ecb_encrypt_4way(struct skcipher_request *req) {
  ECB_WALK_START(req, LEA_BLOCK_SIZE, LEA_SSE2_PARALLEL_BLOCKS);
  ECB_BLOCK(LEA_SSE2_PARALLEL_BLOCKS, lea_ecb_enc_4way);
  ECB_BLOCK(1, __crypto_lea_encrypt);
  ECB_WALK_END();
}

static int ecb_decrypt_4way(struct skcipher_request *req) {
  ECB_WALK_START(req, LEA_BLOCK_SIZE, LEA_SSE2_PARALLEL_BLOCKS);
  ECB_BLOCK(LEA_SSE2_PARALLEL_BLOCKS, lea_ecb_dec_4way);
  ECB_BLOCK(1, __crypto_lea_decrypt);
  ECB_WALK_END();
}

static int cbc_encrypt(struct skcipher_request *req) {
  CBC_WALK_START(req, LEA_BLOCK_SIZE, -1);
  CBC_ENC_BLOCK(__crypto_lea_encrypt);
  CBC_WALK_END();
}

#if defined(__x86_64__)
static int cbc_decrypt_8way(struct skcipher_request *req) {
  CBC_WALK_START(req, LEA_BLOCK_SIZE, LEA_SSE2_PARALLEL_BLOCKS);
  CBC_DEC_BLOCK(LEA_AVX2_PARALLEL_BLOCKS, lea_cbc_dec_8way);
  CBC_DEC_BLOCK(LEA_SSE2_PARALLEL_BLOCKS, lea_cbc_dec_4way);
  CBC_DEC_BLOCK(1, __crypto_lea_decrypt);
  CBC_WALK_END();
}
#endif

static int cbc_decrypt_4way(struct skcipher_request *req) {
  CBC_WALK_START(req, LEA_BLOCK_SIZE, LEA_SSE2_PARALLEL_BLOCKS);
  CBC_DEC_BLOCK(LEA_SSE2_PARALLEL_BLOCKS, lea_cbc_dec_4way);
  CBC_DEC_BLOCK(1, __crypto_lea_decrypt);
  CBC_WALK_END();
}

typedef struct {
  u64 v0, v1;
} _u128;

static inline void xor_1blk(u8 *out, const u8 *in1, const u8 *in2) {
  const _u128 *_in1 = (const _u128 *)in1;
  const _u128 *_in2 = (const _u128 *)in2;
  _u128 *_out = (_u128 *)out;
  _out->v0 = _in1->v0 ^ _in2->v0;
  _out->v1 = _in1->v1 ^ _in2->v1;
}

#if defined(__x86_64__)
static inline void xts_next_tweak(u8 *out, const u8 *in) {
  const u64 *_in = (const u64 *)in;
  u64 *_out = (u64 *)out;
  u64 v0 = _in[0];
  u64 v1 = _in[1];
  u64 carry = (u64)(((s64)v1) >> 63);

  v1 = (v1 << 1) ^ (v0 >> 63);
  v0 = (v0 << 1) ^ ((u64)carry & 0x87);

  _out[0] = v0;
  _out[1] = v1;
}

static int xts_encrypt_8way(struct skcipher_request *req) {
  struct crypto_skcipher *tfm = crypto_skcipher_reqtfm(req);
  struct crypto_tfm *tfm_ctx = crypto_skcipher_ctx(tfm);
  struct lea_xts_ctx *ctx = crypto_tfm_ctx(tfm_ctx);
  struct skcipher_request subreq;
  struct skcipher_walk walk;

  int ret;
  u32 nblocks;
  u32 tail = req->cryptlen % LEA_BLOCK_SIZE;
  u32 edge_tail = 0;

  if (req->cryptlen < LEA_BLOCK_SIZE) {
    return -EINVAL;
  }

  ret = skcipher_walk_virt(&walk, req, false);
  if (ret) {
    return ret;
  }

  if (unlikely(tail != 0 && walk.nbytes < walk.total)) {
    u32 req_len = req->cryptlen - LEA_BLOCK_SIZE - tail;
    skcipher_walk_abort(&walk);

    skcipher_request_set_tfm(&subreq, tfm);
    skcipher_request_set_callback(&subreq, skcipher_request_flags(req), NULL,
                                  NULL);
    skcipher_request_set_crypt(&subreq, req->src, req->dst, req_len, req->iv);
    req = &subreq;
    ret = skcipher_walk_virt(&walk, req, false);
    if (ret) {
      return ret;
    }
    edge_tail = tail;
    tail = 0;
  }

  __crypto_lea_encrypt(ctx->raw_tweak_ctx, walk.iv, walk.iv);

  while ((nblocks = walk.nbytes / LEA_BLOCK_SIZE) > 0) {
    u32 nbytes = walk.nbytes;
    const u8 *src = walk.src.virt.addr;
    u8 *dst = walk.dst.virt.addr;
    bool is_tail = tail != 0 && (nblocks + 1) * LEA_BLOCK_SIZE > walk.total;

    if (unlikely(is_tail)) {
      nblocks -= 1;
    }

    kernel_fpu_begin();

    for (; nblocks >= LEA_AVX2_PARALLEL_BLOCKS;
         nblocks -= LEA_AVX2_PARALLEL_BLOCKS) {
      lea_xts_enc_8way(ctx->raw_crypt_ctx, dst, src, walk.iv);
      src += LEA_AVX2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
      dst += LEA_AVX2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
      nbytes -= LEA_AVX2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
    }

    for (; nblocks >= LEA_SSE2_PARALLEL_BLOCKS;
         nblocks -= LEA_SSE2_PARALLEL_BLOCKS) {
      lea_xts_enc_4way(ctx->raw_crypt_ctx, dst, src, walk.iv);
      src += LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
      dst += LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
      nbytes -= LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
    }

    for (; nblocks > 0; nblocks -= 1) {
      u8 __aligned(16) buffer[LEA_BLOCK_SIZE];

      xor_1blk(buffer, walk.iv, src);
      __crypto_lea_encrypt(ctx->raw_crypt_ctx, buffer, buffer);
      xor_1blk(dst, walk.iv, buffer);
      xts_next_tweak(walk.iv, walk.iv);

      src += LEA_BLOCK_SIZE;
      dst += LEA_BLOCK_SIZE;
      nbytes -= LEA_BLOCK_SIZE;
    }

    if (unlikely(is_tail)) {
      u8 __aligned(16) buffer[LEA_BLOCK_SIZE];

      xor_1blk(buffer, walk.iv, src);
      __crypto_lea_encrypt(ctx->raw_crypt_ctx, buffer, buffer);
      xor_1blk(buffer, walk.iv, buffer);

      memcpy(dst, buffer, LEA_BLOCK_SIZE);
      memcpy(buffer, src + LEA_BLOCK_SIZE, tail);
      memcpy(dst + LEA_BLOCK_SIZE, dst, tail);

      xts_next_tweak(walk.iv, walk.iv);

      xor_1blk(buffer, walk.iv, buffer);
      __crypto_lea_encrypt(ctx->raw_crypt_ctx, buffer, buffer);
      xor_1blk(dst, walk.iv, buffer);

      nbytes -= LEA_BLOCK_SIZE + tail;

      kernel_fpu_end();
      return skcipher_walk_done(&walk, nbytes);
    }

    kernel_fpu_end();
    ret = skcipher_walk_done(&walk, nbytes);
    if (ret) {
      return ret;
    }
  }

  if (unlikely(edge_tail != 0)) {
    u8 __aligned(16) buffer[LEA_BLOCK_SIZE];
    struct scatterlist sg_src[2];
    struct scatterlist sg_dst[2];
    struct scatterlist *scatter_src;
    struct scatterlist *scatter_dst;
    const u8 *src;
    u8 *dst;
    scatter_src = scatterwalk_ffwd(sg_src, req->src, req->cryptlen);
    if (req->src == req->dst) {
      scatter_dst = scatter_src;
    } else {
      scatter_dst = scatterwalk_ffwd(sg_dst, req->dst, req->cryptlen);
    }

    skcipher_request_set_crypt(req, scatter_src, scatter_dst,
                               LEA_BLOCK_SIZE + edge_tail, req->iv);

    ret = skcipher_walk_virt(&walk, req, false);

    src = walk.src.virt.addr;
    dst = walk.dst.virt.addr;

    kernel_fpu_begin();

    xor_1blk(buffer, walk.iv, src);
    __crypto_lea_encrypt(ctx->raw_crypt_ctx, buffer, buffer);
    xor_1blk(buffer, walk.iv, buffer);

    memcpy(dst, buffer, LEA_BLOCK_SIZE);
    memcpy(buffer, src + LEA_BLOCK_SIZE, edge_tail);
    memcpy(dst + LEA_BLOCK_SIZE, dst, edge_tail);

    xts_next_tweak(walk.iv, walk.iv);

    xor_1blk(buffer, walk.iv, buffer);
    __crypto_lea_encrypt(ctx->raw_crypt_ctx, buffer, buffer);
    xor_1blk(dst, walk.iv, buffer);

    kernel_fpu_end();
    ret = skcipher_walk_done(&walk, 0);
  }

  return ret;
}

static int xts_decrypt_8way(struct skcipher_request *req) {
  struct crypto_skcipher *tfm = crypto_skcipher_reqtfm(req);
  struct crypto_tfm *tfm_ctx = crypto_skcipher_ctx(tfm);
  struct lea_xts_ctx *ctx = crypto_tfm_ctx(tfm_ctx);
  struct skcipher_request subreq;
  struct skcipher_walk walk;

  int ret;
  u32 nblocks;
  u32 tail = req->cryptlen % LEA_BLOCK_SIZE;
  u32 edge_tail = 0;

  if (req->cryptlen < LEA_BLOCK_SIZE) {
    return -EINVAL;
  }

  ret = skcipher_walk_virt(&walk, req, false);
  if (ret) {
    return ret;
  }

  if (unlikely(tail != 0 && walk.nbytes < walk.total)) {
    u32 req_len = req->cryptlen - LEA_BLOCK_SIZE - tail;
    skcipher_walk_abort(&walk);

    skcipher_request_set_tfm(&subreq, tfm);
    skcipher_request_set_callback(&subreq, skcipher_request_flags(req), NULL,
                                  NULL);
    skcipher_request_set_crypt(&subreq, req->src, req->dst, req_len, req->iv);
    req = &subreq;
    ret = skcipher_walk_virt(&walk, req, false);
    if (ret) {
      return ret;
    }
    edge_tail = tail;
    tail = 0;
  }

  __crypto_lea_encrypt(ctx->raw_tweak_ctx, walk.iv, walk.iv);

  while ((nblocks = walk.nbytes / LEA_BLOCK_SIZE) > 0) {
    u32 nbytes = walk.nbytes;
    const u8 *src = walk.src.virt.addr;
    u8 *dst = walk.dst.virt.addr;
    bool is_tail = tail != 0 && (nblocks + 1) * LEA_BLOCK_SIZE > walk.total;

    if (unlikely(is_tail)) {
      nblocks -= 1;
    }

    kernel_fpu_begin();

    for (; nblocks >= LEA_AVX2_PARALLEL_BLOCKS;
         nblocks -= LEA_AVX2_PARALLEL_BLOCKS) {
      lea_xts_dec_8way(ctx->raw_crypt_ctx, dst, src, walk.iv);
      src += LEA_AVX2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
      dst += LEA_AVX2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
      nbytes -= LEA_AVX2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
    }

    for (; nblocks >= LEA_SSE2_PARALLEL_BLOCKS;
         nblocks -= LEA_SSE2_PARALLEL_BLOCKS) {
      lea_xts_dec_4way(ctx->raw_crypt_ctx, dst, src, walk.iv);
      src += LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
      dst += LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
      nbytes -= LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
    }

    for (; nblocks > 0; nblocks -= 1) {
      u8 __aligned(16) buffer[LEA_BLOCK_SIZE];

      xor_1blk(buffer, walk.iv, src);
      __crypto_lea_decrypt(ctx->raw_crypt_ctx, buffer, buffer);
      xor_1blk(dst, walk.iv, buffer);
      xts_next_tweak(walk.iv, walk.iv);

      src += LEA_BLOCK_SIZE;
      dst += LEA_BLOCK_SIZE;
      nbytes -= LEA_BLOCK_SIZE;
    }

    if (unlikely(is_tail)) {
      u8 __aligned(16) ntweak[16] = {
          0,
      };
      u8 __aligned(16) buffer[LEA_BLOCK_SIZE];

      memcpy(ntweak, walk.iv, LEA_BLOCK_SIZE);
      xts_next_tweak(walk.iv, ntweak);

      xor_1blk(buffer, walk.iv, src);
      __crypto_lea_decrypt(ctx->raw_crypt_ctx, buffer, buffer);
      xor_1blk(buffer, walk.iv, buffer);

      memcpy(dst, buffer, LEA_BLOCK_SIZE);

      memcpy(buffer, src + 16, tail);
      memcpy(dst + 16, dst, tail);

      xor_1blk(buffer, ntweak, buffer);
      __crypto_lea_decrypt(ctx->raw_crypt_ctx, buffer, buffer);
      xor_1blk(dst, ntweak, buffer);

      nbytes -= LEA_BLOCK_SIZE + tail;

      kernel_fpu_end();
      return skcipher_walk_done(&walk, nbytes);
    }

    kernel_fpu_end();

    ret = skcipher_walk_done(&walk, nbytes);
    if (ret) {
      return ret;
    }
  }

  if (unlikely(edge_tail != 0)) {
    u8 __aligned(16) ntweak[16] = {
        0,
    };
    u8 __aligned(16) buffer[LEA_BLOCK_SIZE];
    struct scatterlist sg_src[2];
    struct scatterlist sg_dst[2];
    struct scatterlist *scatter_src;
    struct scatterlist *scatter_dst;
    const u8 *src;
    u8 *dst;
    scatter_src = scatterwalk_ffwd(sg_src, req->src, req->cryptlen);
    if (req->src == req->dst) {
      scatter_dst = scatter_src;
    } else {
      scatter_dst = scatterwalk_ffwd(sg_dst, req->dst, req->cryptlen);
    }

    skcipher_request_set_crypt(req, scatter_src, scatter_dst,
                               LEA_BLOCK_SIZE + edge_tail, req->iv);

    ret = skcipher_walk_virt(&walk, req, false);

    src = walk.src.virt.addr;
    dst = walk.dst.virt.addr;

    kernel_fpu_begin();

    memcpy(ntweak, walk.iv, LEA_BLOCK_SIZE);
    xts_next_tweak(walk.iv, ntweak);

    xor_1blk(buffer, walk.iv, src);
    __crypto_lea_decrypt(ctx->raw_crypt_ctx, buffer, buffer);
    xor_1blk(buffer, walk.iv, buffer);

    memcpy(dst, buffer, LEA_BLOCK_SIZE);

    memcpy(buffer, src + 16, edge_tail);
    memcpy(dst + 16, dst, edge_tail);

    xor_1blk(buffer, ntweak, buffer);
    __crypto_lea_decrypt(ctx->raw_crypt_ctx, buffer, buffer);
    xor_1blk(dst, ntweak, buffer);

    kernel_fpu_end();
    ret = skcipher_walk_done(&walk, 0);
  }

return ret;
}
#endif

static int ctr_encrypt_4way_no_movbe(struct skcipher_request *req) {
  struct crypto_skcipher *tfm = crypto_skcipher_reqtfm(req);
  struct crypto_lea_ctx *ctx = crypto_skcipher_ctx(tfm);
  struct skcipher_walk walk;
  int ret;

  ret = skcipher_walk_virt(&walk, req, false);
  if (ret) {
    return ret;
  }

  while (walk.nbytes > 0) {
    u32 nbytes = walk.nbytes;
    const u8 *src = walk.src.virt.addr;
    u8 *dst = walk.dst.virt.addr;
    u8 __aligned(16) buffer[LEA_BLOCK_SIZE * 4];

    kernel_fpu_begin();

    while (nbytes >= LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE) {
      lea_ctr_enc_4way_no_movbe(ctx, dst, src, walk.iv);
      src += LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
      dst += LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
      nbytes -= LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
    }

    while (nbytes >= LEA_BLOCK_SIZE) {
      __crypto_lea_encrypt(ctx, buffer, walk.iv);
      xor_1blk(dst, buffer, src);
      crypto_inc(walk.iv, LEA_BLOCK_SIZE);

      src += LEA_BLOCK_SIZE;
      dst += LEA_BLOCK_SIZE;
      nbytes -= LEA_BLOCK_SIZE;
    }

    if (unlikely(nbytes != 0)) {
      __crypto_lea_encrypt(ctx, buffer, walk.iv);
      crypto_xor_cpy(dst, buffer, src, nbytes);
      crypto_inc(walk.iv, LEA_BLOCK_SIZE);

      kernel_fpu_end();
      return skcipher_walk_done(&walk, 0);
    }

    kernel_fpu_end();
    ret = skcipher_walk_done(&walk, nbytes);
    if (ret) {
      return ret;
    }
  }

  return ret;
}

static int ctr_encrypt_4way(struct skcipher_request *req) {
  struct crypto_skcipher *tfm = crypto_skcipher_reqtfm(req);
  struct crypto_lea_ctx *ctx = crypto_skcipher_ctx(tfm);
  struct skcipher_walk walk;

  int ret;

  ret = skcipher_walk_virt(&walk, req, false);
  if (ret) {
    return ret;
  }

  while (walk.nbytes > 0) {
    u32 nbytes = walk.nbytes;
    const u8 *src = walk.src.virt.addr;
    u8 *dst = walk.dst.virt.addr;
    u8 __aligned(16) buffer[LEA_BLOCK_SIZE];

    kernel_fpu_begin();

    while (nbytes >= LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE) {
      lea_ctr_enc_4way(ctx, dst, src, walk.iv);
      src += LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
      dst += LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
      nbytes -= LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
    }

    while (nbytes >= LEA_BLOCK_SIZE) {
      __crypto_lea_encrypt(ctx, buffer, walk.iv);
      xor_1blk(dst, buffer, src);
      crypto_inc(walk.iv, LEA_BLOCK_SIZE);

      src += LEA_BLOCK_SIZE;
      dst += LEA_BLOCK_SIZE;
      nbytes -= LEA_BLOCK_SIZE;
    }

    if (unlikely(nbytes != 0)) {
      __crypto_lea_encrypt(ctx, buffer, walk.iv);
      crypto_xor_cpy(dst, buffer, src, nbytes);
      crypto_inc(walk.iv, LEA_BLOCK_SIZE);

      kernel_fpu_end();
      return skcipher_walk_done(&walk, 0);
    }

    kernel_fpu_end();
    ret = skcipher_walk_done(&walk, nbytes);
    if (ret) {
      return ret;
    }
  }

  return ret;
}

static int ctr_encrypt_8way(struct skcipher_request *req) {
  struct crypto_skcipher *tfm = crypto_skcipher_reqtfm(req);
  struct crypto_lea_ctx *ctx = crypto_skcipher_ctx(tfm);
  struct skcipher_walk walk;

  int ret;

  ret = skcipher_walk_virt(&walk, req, false);
  if (ret) {
    return ret;
  }

  while (walk.nbytes > 0) {
    u32 nbytes = walk.nbytes;
    const u8 *src = walk.src.virt.addr;
    u8 *dst = walk.dst.virt.addr;
    u8 __aligned(32) buffer[LEA_BLOCK_SIZE * LEA_AVX2_PARALLEL_BLOCKS];

    kernel_fpu_begin();

    while (nbytes >= LEA_AVX2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE) {
      lea_ctr_enc_8way(ctx, dst, src, walk.iv, buffer);
      src += LEA_AVX2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
      dst += LEA_AVX2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
      nbytes -= LEA_AVX2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
    }

    while (nbytes >= LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE) {
      lea_ctr_enc_4way(ctx, dst, src, walk.iv);
      src += LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
      dst += LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
      nbytes -= LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
    }

    while (nbytes >= LEA_BLOCK_SIZE) {
      __crypto_lea_encrypt(ctx, buffer, walk.iv);
      xor_1blk(dst, buffer, src);
      crypto_inc(walk.iv, LEA_BLOCK_SIZE);

      src += LEA_BLOCK_SIZE;
      dst += LEA_BLOCK_SIZE;
      nbytes -= LEA_BLOCK_SIZE;
    }

    if (unlikely(nbytes != 0)) {
      __crypto_lea_encrypt(ctx, buffer, walk.iv);
      crypto_xor_cpy(dst, buffer, src, nbytes);
      crypto_inc(walk.iv, LEA_BLOCK_SIZE);

      kernel_fpu_end();
      return skcipher_walk_done(&walk, 0);
    }

    kernel_fpu_end();
    ret = skcipher_walk_done(&walk, nbytes);
    if (ret) {
      return ret;
    }
  }

  return ret;
}

#if defined(__x86_64__)
static int xts_encrypt_4way(struct skcipher_request *req) {
  struct crypto_skcipher *tfm = crypto_skcipher_reqtfm(req);
  struct crypto_tfm *tfm_ctx = crypto_skcipher_ctx(tfm);
  struct lea_xts_ctx *ctx = crypto_tfm_ctx(tfm_ctx);
  struct skcipher_request subreq;
  struct skcipher_walk walk;

  int ret;
  u32 nblocks;
  u32 tail = req->cryptlen % LEA_BLOCK_SIZE;
  u32 edge_tail = 0;

  if (req->cryptlen < LEA_BLOCK_SIZE) {
    return -EINVAL;
  }

  ret = skcipher_walk_virt(&walk, req, false);
  if (ret) {
    return ret;
  }

  if (unlikely(tail != 0 && walk.nbytes < walk.total)) {
    u32 req_len = req->cryptlen - LEA_BLOCK_SIZE - tail;
    skcipher_walk_abort(&walk);

    skcipher_request_set_tfm(&subreq, tfm);
    skcipher_request_set_callback(&subreq, skcipher_request_flags(req), NULL,
                                  NULL);
    skcipher_request_set_crypt(&subreq, req->src, req->dst, req_len, req->iv);
    req = &subreq;
    ret = skcipher_walk_virt(&walk, req, false);
    if (ret) {
      return ret;
    }
    edge_tail = tail;
    tail = 0;
  }

  __crypto_lea_encrypt(ctx->raw_tweak_ctx, walk.iv, walk.iv);

  while ((nblocks = walk.nbytes / LEA_BLOCK_SIZE) > 0) {
    u32 nbytes = walk.nbytes;
    const u8 *src = walk.src.virt.addr;
    u8 *dst = walk.dst.virt.addr;
    bool is_tail = tail != 0 && (nblocks + 1) * LEA_BLOCK_SIZE > walk.total;

    if (unlikely(is_tail)) {
      nblocks -= 1;
    }

    kernel_fpu_begin();

    for (; nblocks >= LEA_SSE2_PARALLEL_BLOCKS;
         nblocks -= LEA_SSE2_PARALLEL_BLOCKS) {
      lea_xts_enc_4way(ctx->raw_crypt_ctx, dst, src, walk.iv);
      src += LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
      dst += LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
      nbytes -= LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
    }

    for (; nblocks > 0; nblocks -= 1) {
      u8 __aligned(16) buffer[LEA_BLOCK_SIZE];

      xor_1blk(buffer, walk.iv, src);
      __crypto_lea_encrypt(ctx->raw_crypt_ctx, buffer, buffer);
      xor_1blk(dst, walk.iv, buffer);
      xts_next_tweak(walk.iv, walk.iv);

      src += LEA_BLOCK_SIZE;
      dst += LEA_BLOCK_SIZE;
      nbytes -= LEA_BLOCK_SIZE;
    }

    if (unlikely(is_tail)) {
      u8 __aligned(16) buffer[LEA_BLOCK_SIZE];

      xor_1blk(buffer, walk.iv, src);
      __crypto_lea_encrypt(ctx->raw_crypt_ctx, buffer, buffer);
      xor_1blk(buffer, walk.iv, buffer);

      memcpy(dst, buffer, LEA_BLOCK_SIZE);
      memcpy(buffer, src + LEA_BLOCK_SIZE, tail);
      memcpy(dst + LEA_BLOCK_SIZE, dst, tail);

      xts_next_tweak(walk.iv, walk.iv);

      xor_1blk(buffer, walk.iv, buffer);
      __crypto_lea_encrypt(ctx->raw_crypt_ctx, buffer, buffer);
      xor_1blk(dst, walk.iv, buffer);

      nbytes -= LEA_BLOCK_SIZE + tail;

      kernel_fpu_end();
      return skcipher_walk_done(&walk, nbytes);
    }

    kernel_fpu_end();
    ret = skcipher_walk_done(&walk, nbytes);
    if (ret) {
      return ret;
    }
  }

  if (unlikely(edge_tail != 0)) {
    u8 __aligned(16) buffer[LEA_BLOCK_SIZE];
    struct scatterlist sg_src[2];
    struct scatterlist sg_dst[2];
    struct scatterlist *scatter_src;
    struct scatterlist *scatter_dst;
    const u8 *src;
    u8 *dst;
    scatter_src = scatterwalk_ffwd(sg_src, req->src, req->cryptlen);
    if (req->src == req->dst) {
      scatter_dst = scatter_src;
    } else {
      scatter_dst = scatterwalk_ffwd(sg_dst, req->dst, req->cryptlen);
    }

    skcipher_request_set_crypt(req, scatter_src, scatter_dst,
                               LEA_BLOCK_SIZE + edge_tail, req->iv);

    ret = skcipher_walk_virt(&walk, req, false);

    src = walk.src.virt.addr;
    dst = walk.dst.virt.addr;

    kernel_fpu_begin();

    xor_1blk(buffer, walk.iv, src);
    __crypto_lea_encrypt(ctx->raw_crypt_ctx, buffer, buffer);
    xor_1blk(buffer, walk.iv, buffer);

    memcpy(dst, buffer, LEA_BLOCK_SIZE);
    memcpy(buffer, src + LEA_BLOCK_SIZE, edge_tail);
    memcpy(dst + LEA_BLOCK_SIZE, dst, edge_tail);

    xts_next_tweak(walk.iv, walk.iv);

    xor_1blk(buffer, walk.iv, buffer);
    __crypto_lea_encrypt(ctx->raw_crypt_ctx, buffer, buffer);
    xor_1blk(dst, walk.iv, buffer);

    kernel_fpu_end();

    ret = skcipher_walk_done(&walk, 0);
  }

  return ret;
}

static int xts_decrypt_4way(struct skcipher_request *req) {
  struct crypto_skcipher *tfm = crypto_skcipher_reqtfm(req);
  struct crypto_tfm *tfm_ctx = crypto_skcipher_ctx(tfm);
  struct lea_xts_ctx *ctx = crypto_tfm_ctx(tfm_ctx);
  struct skcipher_request subreq;
  struct skcipher_walk walk;

  int ret;
  u32 nblocks;
  u32 tail = req->cryptlen % LEA_BLOCK_SIZE;
  u32 edge_tail = 0;

  if (req->cryptlen < LEA_BLOCK_SIZE) {
    return -EINVAL;
  }

  ret = skcipher_walk_virt(&walk, req, false);
  if (ret) {
    return ret;
  }

  if (unlikely(tail != 0 && walk.nbytes < walk.total)) {
    u32 req_len = req->cryptlen - LEA_BLOCK_SIZE - tail;
    skcipher_walk_abort(&walk);

    skcipher_request_set_tfm(&subreq, tfm);
    skcipher_request_set_callback(&subreq, skcipher_request_flags(req), NULL,
                                  NULL);
    skcipher_request_set_crypt(&subreq, req->src, req->dst, req_len, req->iv);
    req = &subreq;
    ret = skcipher_walk_virt(&walk, req, false);
    if (ret) {
      return ret;
    }
    edge_tail = tail;
    tail = 0;
  }

  __crypto_lea_encrypt(ctx->raw_tweak_ctx, walk.iv, walk.iv);

  while ((nblocks = walk.nbytes / LEA_BLOCK_SIZE) > 0) {
    u32 nbytes = walk.nbytes;
    const u8 *src = walk.src.virt.addr;
    u8 *dst = walk.dst.virt.addr;
    bool is_tail = tail != 0 && (nblocks + 1) * LEA_BLOCK_SIZE > walk.total;

    if (unlikely(is_tail)) {
      nblocks -= 1;
    }
    
    kernel_fpu_begin();

    for (; nblocks >= LEA_SSE2_PARALLEL_BLOCKS;
         nblocks -= LEA_SSE2_PARALLEL_BLOCKS) {
      lea_xts_dec_4way(ctx->raw_crypt_ctx, dst, src, walk.iv);
      src += LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
      dst += LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
      nbytes -= LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE;
    }

    for (; nblocks > 0; nblocks -= 1) {
      u8 __aligned(16) buffer[LEA_BLOCK_SIZE];

      xor_1blk(buffer, walk.iv, src);
      __crypto_lea_decrypt(ctx->raw_crypt_ctx, buffer, buffer);
      xor_1blk(dst, walk.iv, buffer);
      xts_next_tweak(walk.iv, walk.iv);

      src += LEA_BLOCK_SIZE;
      dst += LEA_BLOCK_SIZE;
      nbytes -= LEA_BLOCK_SIZE;
    }

    if (unlikely(is_tail)) {
      u8 __aligned(16) ntweak[16] = {
          0,
      };
      u8 __aligned(16) buffer[LEA_BLOCK_SIZE];

      memcpy(ntweak, walk.iv, LEA_BLOCK_SIZE);
      xts_next_tweak(walk.iv, ntweak);

      xor_1blk(buffer, walk.iv, src);
      __crypto_lea_decrypt(ctx->raw_crypt_ctx, buffer, buffer);
      xor_1blk(buffer, walk.iv, buffer);

      memcpy(dst, buffer, LEA_BLOCK_SIZE);

      memcpy(buffer, src + 16, tail);
      memcpy(dst + 16, dst, tail);

      xor_1blk(buffer, ntweak, buffer);
      __crypto_lea_decrypt(ctx->raw_crypt_ctx, buffer, buffer);
      xor_1blk(dst, ntweak, buffer);

      nbytes -= LEA_BLOCK_SIZE + tail;

      kernel_fpu_end();
      return skcipher_walk_done(&walk, nbytes);
    }

    kernel_fpu_end();
    ret = skcipher_walk_done(&walk, nbytes);
    if (ret) {
      return ret;
    }
  }

  if (unlikely(edge_tail != 0)) {
    u8 __aligned(16) ntweak[16] = {
        0,
    };
    u8 __aligned(16) buffer[LEA_BLOCK_SIZE];
    struct scatterlist sg_src[2];
    struct scatterlist sg_dst[2];
    struct scatterlist *scatter_src;
    struct scatterlist *scatter_dst;
    const u8 *src;
    u8 *dst;
    scatter_src = scatterwalk_ffwd(sg_src, req->src, req->cryptlen);
    if (req->src == req->dst) {
      scatter_dst = scatter_src;
    } else {
      scatter_dst = scatterwalk_ffwd(sg_dst, req->dst, req->cryptlen);
    }

    skcipher_request_set_crypt(req, scatter_src, scatter_dst,
                               LEA_BLOCK_SIZE + edge_tail, req->iv);

    ret = skcipher_walk_virt(&walk, req, false);

    src = walk.src.virt.addr;
    dst = walk.dst.virt.addr;

    kernel_fpu_begin();

    memcpy(ntweak, walk.iv, LEA_BLOCK_SIZE);
    xts_next_tweak(walk.iv, ntweak);

    xor_1blk(buffer, walk.iv, src);
    __crypto_lea_decrypt(ctx->raw_crypt_ctx, buffer, buffer);
    xor_1blk(buffer, walk.iv, buffer);

    memcpy(dst, buffer, LEA_BLOCK_SIZE);

    memcpy(buffer, src + 16, edge_tail);
    memcpy(dst + 16, dst, edge_tail);

    xor_1blk(buffer, ntweak, buffer);
    __crypto_lea_decrypt(ctx->raw_crypt_ctx, buffer, buffer);
    xor_1blk(dst, ntweak, buffer);

    kernel_fpu_end();
    ret = skcipher_walk_done(&walk, 0);
  }

  return ret;
}

static int xts_lea_set_key(struct crypto_skcipher *tfm, const u8 *key,
                           u32 keylen) {
  struct crypto_tfm *tfm_ctx = crypto_skcipher_ctx(tfm);
  struct lea_xts_ctx *ctx = crypto_tfm_ctx(tfm_ctx);

  struct crypto_lea_ctx *crypt_key =
      (struct crypto_lea_ctx *)(ctx->raw_crypt_ctx);
  struct crypto_lea_ctx *tweak_key =
      (struct crypto_lea_ctx *)(ctx->raw_tweak_ctx);

  int result = _crypto_lea_set_key(crypt_key, key, keylen / 2);
  if (result != 0) {
    return result;
  }
  return _crypto_lea_set_key(tweak_key, key + (keylen / 2), keylen / 2);
}
#endif

static int _lea_set_key(struct crypto_skcipher *tfm, const u8 *key,
                        u32 keylen) {
  return _crypto_lea_set_key(crypto_skcipher_ctx(tfm), key, keylen);
}

static struct skcipher_alg lea_sse2_algs[] = {
    {
        .base.cra_name = "__ecb(lea)",
        .base.cra_driver_name = "__ecb-lea-sse2",
        .base.cra_priority = 300 - 1,
        .base.cra_flags = CRYPTO_ALG_INTERNAL,
        .base.cra_blocksize = LEA_BLOCK_SIZE,
        .base.cra_ctxsize = sizeof(struct crypto_lea_ctx),
        .base.cra_module = THIS_MODULE,
        .min_keysize = LEA_MIN_KEY_SIZE,
        .max_keysize = LEA_MAX_KEY_SIZE,
        .walksize = LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE,
        .setkey = _lea_set_key,
        .encrypt = ecb_encrypt_4way,
        .decrypt = ecb_decrypt_4way,
    },
    {
        .base.cra_name = "__cbc(lea)",
        .base.cra_driver_name = "__cbc-lea-sse2",
        .base.cra_priority = 300 - 1,
        .base.cra_flags = CRYPTO_ALG_INTERNAL,
        .base.cra_blocksize = LEA_BLOCK_SIZE,
        .base.cra_ctxsize = sizeof(struct crypto_lea_ctx),
        .base.cra_module = THIS_MODULE,
        .min_keysize = LEA_MIN_KEY_SIZE,
        .max_keysize = LEA_MAX_KEY_SIZE,
        .walksize = LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE,
        .ivsize = LEA_BLOCK_SIZE,
        .setkey = _lea_set_key,
        .encrypt = cbc_encrypt,
        .decrypt = cbc_decrypt_4way,
    },
#if defined(__x86_64__)
    {
        .base.cra_name = "__xts(lea)",
        .base.cra_driver_name = "__xts-lea-sse2-single",
        .base.cra_priority = 300 - 1,
        .base.cra_flags = CRYPTO_ALG_INTERNAL,
        .base.cra_blocksize = LEA_BLOCK_SIZE,
        .base.cra_ctxsize = sizeof(struct lea_xts_ctx),
        .base.cra_module = THIS_MODULE,
        .min_keysize = LEA_MIN_KEY_SIZE * 2,
        .max_keysize = LEA_MAX_KEY_SIZE * 2,
        .walksize = LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE,
        .ivsize = LEA_BLOCK_SIZE,
        .setkey = xts_lea_set_key,
        .encrypt = xts_encrypt_4way,
        .decrypt = xts_decrypt_4way,
    },
#endif
};

static struct skcipher_alg lea_sse2_movbe_algs[] = {
    {
        .base.cra_name = "__ctr(lea)",
        .base.cra_driver_name = "__ctr-lea-sse2",
        .base.cra_priority = 300 - 1,
        .base.cra_flags = CRYPTO_ALG_INTERNAL,
        .base.cra_blocksize = 1,
        .base.cra_ctxsize = sizeof(struct crypto_lea_ctx),
        .base.cra_module = THIS_MODULE,
        .min_keysize = LEA_MIN_KEY_SIZE,
        .max_keysize = LEA_MAX_KEY_SIZE,
        .chunksize = LEA_BLOCK_SIZE,
        .walksize = LEA_SSE2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE,
        .ivsize = LEA_BLOCK_SIZE,
        .setkey = _lea_set_key,
        .encrypt = ctr_encrypt_4way,
        .decrypt = ctr_encrypt_4way,
    },
};

static struct skcipher_alg lea_avx2_algs[] = {
    {
        .base.cra_name = "__ecb(lea)",
        .base.cra_driver_name = "__ecb-lea-avx2",
        .base.cra_priority = 300,
        .base.cra_flags = CRYPTO_ALG_INTERNAL,
        .base.cra_blocksize = LEA_BLOCK_SIZE,
        .base.cra_ctxsize = sizeof(struct crypto_lea_ctx),
        .base.cra_module = THIS_MODULE,
        .min_keysize = LEA_MIN_KEY_SIZE,
        .max_keysize = LEA_MAX_KEY_SIZE,
        .walksize = LEA_AVX2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE,
        .setkey = _lea_set_key,
        .encrypt = ecb_encrypt_8way,
        .decrypt = ecb_decrypt_8way,
    },
    {
        .base.cra_name = "__ctr(lea)",
        .base.cra_driver_name = "__ctr-lea-avx2",
        .base.cra_priority = 300,
        .base.cra_flags = CRYPTO_ALG_INTERNAL,
        .base.cra_blocksize = 1,
        .base.cra_ctxsize = sizeof(struct crypto_lea_ctx),
        .base.cra_module = THIS_MODULE,
        .min_keysize = LEA_MIN_KEY_SIZE,
        .max_keysize = LEA_MAX_KEY_SIZE,
        .chunksize = LEA_BLOCK_SIZE,
        .walksize = LEA_AVX2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE,
        .ivsize = LEA_BLOCK_SIZE,
        .setkey = _lea_set_key,
        .encrypt = ctr_encrypt_8way,
        .decrypt = ctr_encrypt_8way,
    },
#if defined(__x86_64__)
    {
        .base.cra_name = "__cbc(lea)",
        .base.cra_driver_name = "__cbc-lea-avx2",
        .base.cra_priority = 300,
        .base.cra_flags = CRYPTO_ALG_INTERNAL,
        .base.cra_blocksize = LEA_BLOCK_SIZE,
        .base.cra_ctxsize = sizeof(struct crypto_lea_ctx),
        .base.cra_module = THIS_MODULE,
        .min_keysize = LEA_MIN_KEY_SIZE,
        .max_keysize = LEA_MAX_KEY_SIZE,
        .walksize = LEA_AVX2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE,
        .ivsize = LEA_BLOCK_SIZE,
        .setkey = _lea_set_key,
        .encrypt = cbc_encrypt,
        .decrypt = cbc_decrypt_8way,
    },
    {
        .base.cra_name = "__xts(lea)",
        .base.cra_driver_name = "__xts-lea-avx2-single",
        .base.cra_priority = 300,
        .base.cra_flags = CRYPTO_ALG_INTERNAL,
        .base.cra_blocksize = LEA_BLOCK_SIZE,
        .base.cra_ctxsize = sizeof(struct lea_xts_ctx),
        .base.cra_module = THIS_MODULE,
        .min_keysize = LEA_MIN_KEY_SIZE * 2,
        .max_keysize = LEA_MAX_KEY_SIZE * 2,
        .walksize = LEA_AVX2_PARALLEL_BLOCKS * LEA_BLOCK_SIZE,
        .ivsize = LEA_BLOCK_SIZE,
        .setkey = xts_lea_set_key,
        .encrypt = xts_encrypt_8way,
        .decrypt = xts_decrypt_8way,
    },
#endif
};

static struct simd_skcipher_alg *lea_sse2_simd_algs[ARRAY_SIZE(lea_sse2_algs)];
static struct simd_skcipher_alg
    *lea_sse2_movbe_simd_algs[ARRAY_SIZE(lea_sse2_movbe_algs)];
static struct simd_skcipher_alg *lea_avx2_simd_algs[ARRAY_SIZE(lea_avx2_algs)];

static bool sse2_loaded = false;
static bool avx2_loaded = false;

static int __init crypto_lea_simd_init(void) {
  const char *feature_name;
  u32 result;

  if (!boot_cpu_has(X86_FEATURE_XMM2)) {
    pr_info("SSE2 instructions are not detected.\n");
    return -ENODEV;
  }

  sse2_loaded = true;

  if (!cpu_has_xfeatures(XFEATURE_MASK_SSE, &feature_name)) {
    pr_info("CPU feature '%s' is not supported.\n", feature_name);
    return -ENODEV;
  }
  printk(KERN_DEBUG "Crypto LEA SIMD SSE2 Load.");
  result = simd_register_skciphers_compat(
      lea_sse2_algs, ARRAY_SIZE(lea_sse2_algs), lea_sse2_simd_algs);
  if (result) {
    return result;
  }

  if (!boot_cpu_has(X86_FEATURE_MOVBE)) {
    lea_sse2_movbe_algs[0].encrypt = ctr_encrypt_4way_no_movbe;
    lea_sse2_movbe_algs[0].decrypt = ctr_encrypt_4way_no_movbe;
    result = simd_register_skciphers_compat(lea_sse2_movbe_algs,
                                            ARRAY_SIZE(lea_sse2_movbe_algs),
                                            lea_sse2_movbe_simd_algs);
    return result;
  }

  result = simd_register_skciphers_compat(lea_sse2_movbe_algs,
                                          ARRAY_SIZE(lea_sse2_movbe_algs),
                                          lea_sse2_movbe_simd_algs);
  if (result) {
    return result;
  }

  if (!boot_cpu_has(X86_FEATURE_AVX2) || !boot_cpu_has(X86_FEATURE_AVX)) {
    return result;
  }

  if (!cpu_has_xfeatures(XFEATURE_MASK_YMM, &feature_name)) {
    return result;
  }

  avx2_loaded = true;

  printk(KERN_DEBUG "Crypto LEA SIMD AVX2 Load.");
  return simd_register_skciphers_compat(
      lea_avx2_algs, ARRAY_SIZE(lea_avx2_algs), lea_avx2_simd_algs);
}

static void __exit crypto_lea_simd_exit(void) {
  if (!sse2_loaded) {
    return;
  }

  simd_unregister_skciphers(lea_sse2_movbe_algs,
                            ARRAY_SIZE(lea_sse2_movbe_algs),
                            lea_sse2_movbe_simd_algs);

  simd_unregister_skciphers(lea_sse2_algs, ARRAY_SIZE(lea_sse2_algs),
                            lea_sse2_simd_algs);

  if (!avx2_loaded) {
    return;
  }
  simd_unregister_skciphers(lea_avx2_algs, ARRAY_SIZE(lea_avx2_algs),
                            lea_avx2_simd_algs);
}

module_init(crypto_lea_simd_init);
module_exit(crypto_lea_simd_exit);

MODULE_DESCRIPTION("LEA Cipher Algorithm, AVX2, SSE2 SIMD");
MODULE_AUTHOR("Dongsoo Lee <letrhee@nsr.re.kr>");
MODULE_LICENSE("GPL");
MODULE_ALIAS_CRYPTO("lea");
MODULE_ALIAS_CRYPTO("lea-simd");