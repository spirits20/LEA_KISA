# Linux LEA 암호 모듈 테스트 도구
- 버전: 1.0

## 설명

Linux LEA 암호 모듈이 정상 동작하는지 확인하기 위한 테스트 도구입니다.

테스트 벡터는 KISA에서 배포중인 Standalone C 모듈의 것을 사용했습니다.

본 테스트 코드는 커널 모듈로 작성되어 Linux 커널 라이선스를 따라 GPL-2.0-or-later 라이선스를 따릅니다.

## 사용방법

테스트하기 위해 다음과 같은 절차를 거칠 수 있습니다.

본 테스트 모듈은 `crypto_lea_test` 디렉토리, 실제 LEA 암호 모듈은 `crypto_lea` 디렉토리에 있다고 가정합니다.

```sh
#LEA 암호 모듈 탑재
insmod crypto_lea.ko #LEA 범용 암호 모듈 적재
insmod crypto_lea_simd.ko #x86-64용 LEA 고속 암호 모듈 적재
cd ../crypto_lea_test

#테스트 모듈
make
insmod crypto_lea_test.ko #테스트 모듈 적재
dmesg --color=always | tail -n 100 #최근 커널 로그 메시지 확인
```

빌드 환경에 필요한 구성물은 `crypto_lea` 모듈을 참고하여 주십시오.

## 파일 안내

### `Makefile`
리눅스 커널 모듈 생성을 위한 Helper makefile입니다.

### `Kbuild`
실제 리눅스 커널 모듈 생성 Makefile 구성 파일입니다.

### `crypto_test.c`, `.h`

모듈 진입 파일입니다.

### `local_tv_*.h`, `local_lea_vs.h`

테스트 벡터가 담겨 있는 파일입니다.

ECB, CBC, CTR, XTS, GCM 모드에 대해서 테스트합니다.

### `dbg.c`

HEX 출력 등 디버그 유틸리티가 담겨있습니다.

### `lea_vs.c`

실제 테스트 코드입니다. 리눅스 커널 내에서 Crypto API를 이용하여 암/복호화를 수행하는 방법을 확인할 수 있으나 검증을 위한 코드이므로 성능 최적화가 되어있지 않습니다.

### `cleanse_compile_command.sh`

Visual Studio Code 등에서 `clangd`를 이용한 개발 환경을 구성할 때 `gcc` 전용 컴파일 플래그를 제거하는데 사용됩니다. 다음과 같이 사용할 수 있습니다.

```sh
make clean
bear -- make
./cleanse_compile_comand.sh
```

Ubuntu 22.04.1 기준으로 `clangd`에서 별도 에러 메시지 없이 `bear` 실행을 통해 생성 된 `compile_command.json` 파일이 정리됩니다.

## 변경 사항
### 1.0 (2023-03-06)
초기 릴리즈