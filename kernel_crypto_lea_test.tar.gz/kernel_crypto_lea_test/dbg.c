#include "crypto_test.h"

#pragma GCC diagnostic ignored "-Wunused-function"

#ifndef NO_DBG_PRINT

#define WORD_SIZE ((u32)sizeof(u32))
#define EACH_LINE 4u

int sprint_word(char *buffer, const u8 *v) {
  return sprintf(buffer, "%02x%02x%02x%02x ", v[0], v[01], v[2], v[3]);
}

void print_both(const u8 *lhs, const u8 *rhs, u32 len) {
  // 6 + (8 + 1) * 4 * 2 + 2 = 80
  u32 lines = len / (WORD_SIZE * EACH_LINE);
  char buffer[6 + (WORD_SIZE * 2 + 1) * EACH_LINE * 2 + 2 + 20] = "";

  const u8 *lhs_end = lhs + len;
  const u8 *rhs_end = rhs + len;

  for (u32 line_idx = 0; line_idx < lines; line_idx++) {
    char *ptr = buffer;
    ptr += sprintf(ptr, "%04x: ", line_idx * EACH_LINE * WORD_SIZE);
    for (u32 offset = 0; offset < EACH_LINE; offset++, lhs += WORD_SIZE) {
      ptr += sprint_word(ptr, lhs);
    }
    ptr += sprintf(ptr, "| ");
    for (u32 offset = 0; offset < EACH_LINE; offset++, rhs += WORD_SIZE) {
      ptr += sprint_word(ptr, rhs);
    }
    pr_info("%s\n", buffer);
  }

  u32 remain = len - lines * EACH_LINE * WORD_SIZE;
  if (remain != 0) {
    char *ptr = buffer;
    ptr += sprintf(ptr, "%04x: ", lines * EACH_LINE * WORD_SIZE);
    for (u32 offset = 0; offset + WORD_SIZE <= remain;
         offset += WORD_SIZE, lhs += WORD_SIZE) {
      ptr += sprint_word(ptr, lhs);
    }
    while (lhs != lhs_end) {
      ptr += sprintf(ptr, "%02x", *lhs);
      lhs++;
    }
    for (u32 ch_idx = remain; ch_idx < WORD_SIZE * EACH_LINE; ch_idx++) {
      *ptr = ' ';
      ptr++;
      *ptr = ' ';
      ptr++;
      if (ch_idx % 4 == 3) {
        *ptr = ' ';
        ptr++;
      }
    }
    ptr += sprintf(ptr, "| ");
    for (u32 offset = 0; offset + WORD_SIZE <= remain;
         offset += WORD_SIZE, rhs += WORD_SIZE) {
      ptr += sprint_word(ptr, rhs);
    }
    while (rhs != rhs_end) {
      ptr += sprintf(ptr, "%02x", *rhs);
      rhs++;
    }
    pr_info("%s\n", buffer);
  }
}

void print_hex(const u8 *item, u32 len) {
  // 6 + (8 + 1) * 8
  u32 lines = len / (WORD_SIZE * EACH_LINE * 2);
  char buffer[6 + (WORD_SIZE * 2 + 1) * EACH_LINE * 2 + 20] = "";

  const u8 *item_end = item + len;

  for (u32 line_idx = 0; line_idx < lines; line_idx++) {
    char *ptr = buffer;
    ptr += sprintf(ptr, "%04x: ", line_idx * EACH_LINE * 2 * WORD_SIZE);
    for (u32 offset = 0; offset < EACH_LINE * 2; offset++, item += WORD_SIZE) {
      ptr += sprint_word(ptr, item);
    }
    pr_info("%s\n", buffer);
  }

  u32 remain = len - lines * EACH_LINE * 2 * WORD_SIZE;
  if (remain != 0) {
    char *ptr = buffer;
    ptr += sprintf(ptr, "%04x: ", lines * EACH_LINE * 2 * WORD_SIZE);
    for (u32 offset = 0; offset + WORD_SIZE <= remain;
         offset += WORD_SIZE, item += WORD_SIZE) {
      ptr += sprint_word(ptr, item);
    }
    while (item != item_end) {
      ptr += sprintf(ptr, "%02x", *item);
      item++;
    }
    pr_info("%s\n", buffer);
  }
}

#endif