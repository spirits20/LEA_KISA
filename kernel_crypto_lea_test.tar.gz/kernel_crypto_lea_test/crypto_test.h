#ifndef CRYPTO_TEST_H
#define CRYPTO_TEST_H
#include <linux/types.h>
#include <linux/crypto.h>

#ifdef NO_DBG_PRINT
#define sprint_word(a, b)
#define print_both(a, b, c)
#define print_hex(a, b)
#else
int sprint_word(char *buffer, const u8 *v);
void print_both(const u8 *lhs, const u8 *rhs, u32 len);
void print_hex(const u8 *item, u32 len);
#endif

int api_1block(void);
int api_4block(void);
int api_8block(void);

int lea_mmt_ecb_test(void);
int lea_mmt_cbc_test(void);
int lea_mmt_ctr_test(void);
int lea_mmt_xts_test(void);
int lea_ae_gcm_test(void);

#define ERR_INVALID_CIPHER  100
#define ERR_KEY_NOT_SET     101
#define ERR_UNKNOWN         102
#define ERR_ALLOC_ERR       103
#define ERR_INVALID_CALL    104
#define ERR_INVALID_ENC     105
#define ERR_INVALID_DEC     106

#define MODULE_PREFIX "CRPYTO_TEST: "

#endif