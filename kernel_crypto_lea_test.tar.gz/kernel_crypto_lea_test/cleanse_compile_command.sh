#/bin/bash
cat compile_commands.json  |
 sed 's/"-mpreferred-stack-boundary=3",//g' |
 sed 's/"-mindirect-branch=thunk-extern",//g' |
 sed 's/"-mfunction-return=thunk-extern",//g' |
 sed 's/"-mindirect-branch-register",//g' |
 sed 's/"-fno-allow-store-data-races",//g' |
 sed 's/"-fconserve-stack",//g' |
 sed 's/"-mrecord-mcount",//g' |
 sed 's/"-mindirect-branch-cs-prefix",//g' |
 cat > compile_commands.json