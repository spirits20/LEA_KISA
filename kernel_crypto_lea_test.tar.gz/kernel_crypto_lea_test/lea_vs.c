#include "crypto_test.h"
#include <crypto/skcipher.h>
#include <crypto/aead.h>
#include <linux/crypto.h>
#include <linux/module.h>
#include <linux/scatterlist.h>
#include "local_lea_vs.h"
#include "local_tv_ecb.h"
#include "local_tv_cbc.h"
#include "local_tv_ctr.h"
#include "local_tv_xts.h"
#include "local_tv_gcm.h"

MODULE_AUTHOR("Dongsoo Lee");
MODULE_LICENSE("GPL");

static int test_crypto_encrypt(const char *alg_name, bool is_enc, u8 *out,
                          u32 outlen, const u8 *in, u32 inlen, u8 *iv,
                          const u8 *key, u32 keylen) {
  struct scatterlist sg_in[2];
  struct scatterlist sg_out[2];
  struct crypto_skcipher *cipher = crypto_alloc_skcipher(alg_name, 0, 0);
  if (IS_ERR(cipher)) {
    int err = PTR_ERR(cipher);
    if (err == -ENOENT) {
      pr_warn("%s is unavailable\n", alg_name);
      return ERR_INVALID_CIPHER;
    }
    pr_err("alg: skcipher: error allocating %s: %d\n", alg_name, err);
    return ERR_INVALID_CIPHER;
  }

  int test_result = 0;

  struct skcipher_request *req = skcipher_request_alloc(cipher, GFP_KERNEL);
  if (!req) {
    pr_info("could not allocate skcipher request\n");
    test_result = ERR_ALLOC_ERR;
    goto fin;
  }

  if (crypto_skcipher_setkey(cipher, key, keylen)) {
    test_result = ERR_KEY_NOT_SET;
    goto fin;
  }

  sg_init_one(sg_in, in, inlen);

  sg_init_one(sg_out, out, outlen);

  skcipher_request_set_crypt(req, sg_in, sg_out, inlen, iv);

  int result;
  if (is_enc) {
    result = crypto_skcipher_encrypt(req);
  } else {
    result = crypto_skcipher_decrypt(req);
  }

  if (result != 0) {
    printk(MODULE_PREFIX "response d: %d, %d\n", result, is_enc);
    test_result = ERR_INVALID_CALL;
    goto fin;
  }

fin:
  if (req)
    skcipher_request_free(req);
  if (cipher)
    crypto_free_skcipher(cipher);
  return test_result;
}


static int test_crypto_aead_encrypt(const char *alg_name, bool is_enc, u8 *out,
                          u32 outlen, const u8 *in, u32 inlen, const u8 *aad, u32 aadlen, u8 *iv, 
                          const u8 *key, u32 keylen) {
  struct scatterlist sg_in[3];
  struct scatterlist sg_out[3];
  struct crypto_aead *cipher = NULL;
  struct aead_request *req = NULL;
  int test_result = 0;
  int err = 0;
  const u32 authsize = 16;

  cipher = crypto_alloc_aead(alg_name, 0, 0);
  if (IS_ERR(cipher)) {
    int err = PTR_ERR(cipher);
    if (err == -ENOENT) {
      pr_warn("%s is unavailable\n", alg_name);
      return ERR_INVALID_CIPHER;
    }
    pr_err("alg: aead: error allocating %s: %d\n", alg_name, err);
    return ERR_INVALID_CIPHER;
  }

  err = crypto_aead_setauthsize(cipher, authsize);
  if(err){
    pr_info("err setauthsize %d\n", err);
    test_result = ERR_ALLOC_ERR;
    goto fin;
  }

  if (crypto_aead_setkey(cipher, key, keylen)) {
    test_result = ERR_KEY_NOT_SET;
    goto fin;
  }

  req = aead_request_alloc(cipher, GFP_KERNEL);
  if (!req) {
    pr_info("could not allocate aead request\n");
    test_result = ERR_ALLOC_ERR;
    goto fin;
  }

  if(aadlen){
    sg_init_table(sg_in, 3);
    sg_set_buf(&sg_in[0], aad, aadlen);
    sg_set_buf(&sg_in[1], in, inlen);
    sg_set_buf(&sg_in[2], in + inlen, authsize);

    sg_init_table(sg_out, 3);
    sg_set_buf(&sg_out[0], aad, aadlen);
    sg_set_buf(&sg_out[1], out, inlen);
    sg_set_buf(&sg_out[2], out + inlen, authsize);
  }
  else{
    sg_init_table(sg_in, 2);
    sg_set_buf(&sg_in[0], in, inlen);
    sg_set_buf(&sg_in[1], in + inlen, authsize);

    sg_init_table(sg_out, 2);
    sg_set_buf(&sg_out[0], out, inlen);
    sg_set_buf(&sg_out[1], out + inlen, authsize);
  }

  aead_request_set_tfm(req, cipher);
  aead_request_set_ad(req, aadlen);
  aead_request_set_crypt(req, sg_in, sg_out, inlen, iv);

  int result;
  if (is_enc) {
    result = crypto_aead_encrypt(req);
  } else {
    result = crypto_aead_decrypt(req);
  }

  if (result != 0) {
    printk(MODULE_PREFIX "response d: %d, %d\n", result, is_enc);
    test_result = ERR_INVALID_CALL;
    goto fin;
  }

fin:
  if (req)
    aead_request_free(req);
  if (cipher)
    crypto_free_aead(cipher);

  return test_result;
}


#define TEST_ITEM(test)                                                        \
  do {                                                                         \
    int res = test;                                                            \
    if (res != 0) {                                                            \
      printk("alg: %s, keylen: %d, idx: %d, FAILED %d\n", alg_name, keylen, i, \
             res);                                                             \
      result = res;                                                            \
      goto fin;                                                                \
    }                                                                          \
  } while (0);

#define COMPARE_ITEM(lhs, rhs, len, encMode)                                   \
  if (memcmp(lhs, rhs, len)) {                                                 \
    print_both(lhs, rhs, len);                                                 \
    result = -keylen * 1000 - i * 10 - ((int)encMode);                         \
    goto fin;                                                                  \
  }

int lea_mmt_ecb_test(void) {
  unsigned int i;
  unsigned char answ[176];
  const char *alg_name = "ecb(lea)";
  pr_info("test %s\n", alg_name);
  u32 keylen = 16;
  LEA_MMT_ECB *target;
  u32 result = 0;

  target = kzalloc(sizeof(LEA_MMT_ECB), GFP_KERNEL);
  for (i = 0; i < 10; i++) {
    u32 inlen = (i + 1) * 16;
    memset(answ, 0, sizeof(answ));
    *target = lea128_mmt_ecb[i];

    TEST_ITEM(test_crypto_encrypt(alg_name, true, answ, inlen, target->p, inlen,
                             NULL, target->key, keylen));

    COMPARE_ITEM(answ, target->c, inlen, true);

    TEST_ITEM(test_crypto_encrypt(alg_name, false, answ, sizeof(answ), answ, inlen,
                             NULL, target->key, keylen));

    COMPARE_ITEM(answ, target->p, inlen, false);
  }

  keylen = 24;
  for (i = 0; i < 10; i++) {
    u32 inlen = (i + 1) * 16;
    memset(answ, 0, sizeof(answ));
    *target = lea192_mmt_ecb[i];

    TEST_ITEM(test_crypto_encrypt(alg_name, true, answ, inlen, target->p, inlen,
                             NULL, target->key, keylen));

    COMPARE_ITEM(answ, target->c, inlen, true);

    TEST_ITEM(test_crypto_encrypt(alg_name, false, answ, sizeof(answ), answ, inlen,
                             NULL, target->key, keylen));

    COMPARE_ITEM(answ, target->p, inlen, false);
  }

  keylen = 32;
  for (i = 0; i < 10; i++) {
    u32 inlen = (i + 1) * 16;
    memset(answ, 0, sizeof(answ));
    *target = lea256_mmt_ecb[i];

    TEST_ITEM(test_crypto_encrypt(alg_name, true, answ, inlen, target->p, inlen,
                             NULL, target->key, keylen));

    COMPARE_ITEM(answ, target->c, inlen, true);

    TEST_ITEM(test_crypto_encrypt(alg_name, false, answ, sizeof(answ), answ, inlen,
                             NULL, target->key, keylen));

    COMPARE_ITEM(answ, target->p, inlen, false);
  }

fin:
  if (result == 0) {
    pr_info("LEA MMT ECB : success\n");
  } else {
    pr_warn("LEA MMT ECB : failed\n");
  }

  if (target != NULL) {
    kvfree(target);
  }

  return result;
}

int lea_mmt_cbc_test(void) {
  unsigned int i;
  unsigned char answ[176];
  u8 iv_buffer[16];
  const char *alg_name = "cbc(lea)";
  pr_info("test %s\n", alg_name);
  u32 keylen = 16;
  LEA_MMT_CBC *target;
  u32 result = 0;

  target = kzalloc(sizeof(LEA_MMT_CBC), GFP_KERNEL);

  for (i = 0; i < 10; i++) {
    u32 inlen = (i + 1) * 16;

    *target = lea128_mmt_cbc[i];
    memset(answ, 0, sizeof(answ));
    memcpy(iv_buffer, target->iv, 16);

    TEST_ITEM(test_crypto_encrypt(alg_name, true, answ, sizeof(answ), target->p,
                             inlen, iv_buffer, target->key, keylen));

    COMPARE_ITEM(answ, target->c, inlen, true);

    memcpy(iv_buffer, target->iv, 16);
    TEST_ITEM(test_crypto_encrypt(alg_name, false, answ, sizeof(answ), answ, inlen,
                             iv_buffer, target->key, keylen));

    COMPARE_ITEM(answ, target->p, inlen, false);
  }

  keylen = 24;
  for (i = 0; i < 10; i++) {
    u32 inlen = (i + 1) * 16;

    *target = lea192_mmt_cbc[i];
    memset(answ, 0, sizeof(answ));
    memcpy(iv_buffer, target->iv, 16);

    TEST_ITEM(test_crypto_encrypt(alg_name, true, answ, sizeof(answ), target->p,
                             inlen, iv_buffer, target->key, keylen));

    COMPARE_ITEM(answ, target->c, inlen, true);

    memcpy(iv_buffer, target->iv, 16);
    TEST_ITEM(test_crypto_encrypt(alg_name, false, answ, sizeof(answ), answ, inlen,
                             iv_buffer, target->key, keylen));

    COMPARE_ITEM(answ, target->p, inlen, false);
  }

  keylen = 32;
  for (i = 0; i < 10; i++) {
    u32 inlen = (i + 1) * 16;

    *target = lea256_mmt_cbc[i];
    memset(answ, 0, sizeof(answ));
    memcpy(iv_buffer, target->iv, 16);

    TEST_ITEM(test_crypto_encrypt(alg_name, true, answ, sizeof(answ), target->p,
                             inlen, iv_buffer, target->key, keylen));

    COMPARE_ITEM(answ, target->c, inlen, true);

    memcpy(iv_buffer, target->iv, 16);
    TEST_ITEM(test_crypto_encrypt(alg_name, false, answ, sizeof(answ), answ, inlen,
                             iv_buffer, target->key, keylen));

    COMPARE_ITEM(answ, target->p, inlen, false);
  }

fin:
  if (result == 0) {
    pr_info("LEA MMT CBC : success\n");
  } else {
    pr_warn("LEA MMT CBC : failed\n");
  }

  if (target != NULL) {
    kvfree(target);
  }

  return result;
}

int lea_mmt_ctr_test(void) {
  unsigned int i;
  unsigned char answ[160];
  u8 iv_buffer[16];
  const char *alg_name = "ctr(lea)";
  pr_info("test %s\n", alg_name);
  u32 keylen = 16;
  LEA_MMT_CTR *target;
  u32 result = 0;

  target = kzalloc(sizeof(LEA_MMT_CTR), GFP_KERNEL);

  for (i = 0; i < 10; i++) {
    u32 inlen = (i + 1) * 16;

    *target = lea128_mmt_ctr[i];
    memset(answ, 0, sizeof(answ));
    memcpy(iv_buffer, target->iv, 16);

    TEST_ITEM(test_crypto_encrypt(alg_name, true, answ, sizeof(answ), target->p,
                             inlen, iv_buffer, target->key, keylen));

    COMPARE_ITEM(answ, target->c, inlen, true);

    memcpy(iv_buffer, target->iv, 16);
    TEST_ITEM(test_crypto_encrypt(alg_name, false, answ, sizeof(answ), answ, inlen,
                             iv_buffer, target->key, keylen));

    COMPARE_ITEM(answ, target->p, inlen, false);
  }

  keylen = 24;
  for (i = 0; i < 10; i++) {
    u32 inlen = (i + 1) * 16;

    *target = lea192_mmt_ctr[i];
    memset(answ, 0, sizeof(answ));
    memcpy(iv_buffer, target->iv, 16);

    TEST_ITEM(test_crypto_encrypt(alg_name, true, answ, sizeof(answ), target->p,
                             inlen, iv_buffer, target->key, keylen));

    COMPARE_ITEM(answ, target->c, inlen, true);

    memcpy(iv_buffer, target->iv, 16);
    TEST_ITEM(test_crypto_encrypt(alg_name, false, answ, sizeof(answ), answ, inlen,
                             iv_buffer, target->key, keylen));

    COMPARE_ITEM(answ, target->p, inlen, false);
  }

  keylen = 32;
  for (i = 0; i < 10; i++) {
    u32 inlen = (i + 1) * 16;

    *target = lea256_mmt_ctr[i];
    memset(answ, 0, sizeof(answ));
    memcpy(iv_buffer, target->iv, 16);

    TEST_ITEM(test_crypto_encrypt(alg_name, true, answ, sizeof(answ), target->p,
                             inlen, iv_buffer, target->key, keylen));

    COMPARE_ITEM(answ, target->c, inlen, true);

    memcpy(iv_buffer, target->iv, 16);
    TEST_ITEM(test_crypto_encrypt(alg_name, false, answ, sizeof(answ), answ, inlen,
                             iv_buffer, target->key, keylen));

    COMPARE_ITEM(answ, target->p, inlen, false);
  }

fin:
  if (result == 0) {
    pr_info("LEA MMT CTR : success\n");
  } else {
    pr_warn("LEA MMT CTR : failed\n");
  }

  if (target != NULL) {
    kvfree(target);
  }

  return result;
}

int lea_mmt_xts_test(void) {
  unsigned int i;
  unsigned int inlen;
  unsigned char answ[336];
  const LEA_MMT_XTS *test_type;
  u8 iv_buffer[16];
  u8 key[64];
  const char *alg_name = "xts(lea)";
  pr_info("test %s\n", alg_name);
  u32 keylen;
  LEA_MMT_XTS *target;
  u32 result = 0;

  target = kzalloc(sizeof(LEA_MMT_XTS), GFP_KERNEL);

  test_type = lea128_mmt_xts;
  keylen = 32;
  for (i = 0; i < sizeof(lea128_mmt_xts) / sizeof(LEA_MMT_XTS); i++) {
    inlen = 16 + 5 * i;
    *target = test_type[i];
    memset(answ, 0, sizeof(answ));
    memcpy(iv_buffer, target->tweak, 16);
    memcpy(key, target->key, keylen / 2);
    memcpy(key + keylen / 2, target->tweak_key, keylen / 2);

    TEST_ITEM(test_crypto_encrypt(alg_name, true, answ, sizeof(answ), target->p,
                             inlen, iv_buffer, key, keylen));

    COMPARE_ITEM(answ, target->c, inlen, true);

    memcpy(iv_buffer, target->tweak, 16);
    TEST_ITEM(test_crypto_encrypt(alg_name, false, answ, sizeof(answ), answ, inlen,
                             iv_buffer, key, keylen));

    COMPARE_ITEM(answ, target->p, inlen, false);
  }

  test_type = lea192_mmt_xts;
  keylen = 48;
  for (i = 0; i < sizeof(lea192_mmt_xts) / sizeof(LEA_MMT_XTS); i++) {
    inlen = 16 + 5 * i;
    *target = test_type[i];
    memset(answ, 0, sizeof(answ));
    memcpy(iv_buffer, target->tweak, 16);
    memcpy(key, target->key, keylen / 2);
    memcpy(key + keylen / 2, target->tweak_key, keylen / 2);

    TEST_ITEM(test_crypto_encrypt(alg_name, true, answ, sizeof(answ), target->p,
                             inlen, iv_buffer, key, keylen));

    COMPARE_ITEM(answ, target->c, inlen, true);

    memcpy(iv_buffer, target->tweak, 16);
    TEST_ITEM(test_crypto_encrypt(alg_name, false, answ, sizeof(answ), answ, inlen,
                             iv_buffer, key, keylen));

    COMPARE_ITEM(answ, target->p, inlen, false);
  }

  test_type = lea256_mmt_xts;
  keylen = 64;
  for (i = 0; i < sizeof(lea128_mmt_xts) / sizeof(LEA_MMT_XTS); i++) {
    inlen = 16 + 5 * i;
    *target = test_type[i];
    memset(answ, 0, sizeof(answ));
    memcpy(iv_buffer, target->tweak, 16);
    memcpy(key, target->key, keylen / 2);
    memcpy(key + keylen / 2, target->tweak_key, keylen / 2);

    TEST_ITEM(test_crypto_encrypt(alg_name, true, answ, sizeof(answ), target->p,
                             inlen, iv_buffer, key, keylen));

    COMPARE_ITEM(answ, target->c, inlen, true);

    memcpy(iv_buffer, target->tweak, 16);
    TEST_ITEM(test_crypto_encrypt(alg_name, false, answ, sizeof(answ), answ, inlen,
                             iv_buffer, key, keylen));

    COMPARE_ITEM(answ, target->p, inlen, false);
  }

fin:
  if (result == 0) {
    pr_info("LEA MMT XTS : success\n");
  } else {
    pr_warn("LEA MMT XTS : failed\n");
  }

  if (target != NULL) {
    kvfree(target);
  }

  return result;
}


int lea_ae_gcm_test(void) {
  unsigned int i;
  unsigned int inlen;
  unsigned char answ[360];
  const LEA_GCM_AE *test_type;
  u8 iv_buffer[16];
  const char *alg_name = "gcm(lea)";
  pr_info("test %s\n", alg_name);
  u32 keylen;
  LEA_GCM_AE *target;
  u32 result = 0;

  target = kzalloc(sizeof(LEA_GCM_AE), GFP_KERNEL);

  test_type = lea128_gcm_ae;
  keylen = 16;
  for (i = 0; i < sizeof(lea128_gcm_ae) / sizeof(LEA_GCM_AE); i++) {
    *target = test_type[i];
    inlen = target->p_len;

    memset(answ, 0, sizeof(answ));
    memcpy(iv_buffer, target->nonce, 16);

    TEST_ITEM(test_crypto_aead_encrypt(alg_name, true, answ, sizeof(answ), target->p,
                             inlen, target->assoc, target->assoc_len, iv_buffer, target->key, keylen));

    COMPARE_ITEM(answ, target->c, inlen, true);
    COMPARE_ITEM(answ + inlen, target->tag, 16, 2);

    memcpy(iv_buffer, target->nonce, 16);
    TEST_ITEM(test_crypto_aead_encrypt(alg_name, false, answ, sizeof(answ), answ, inlen + 16, target->assoc, target->assoc_len,
                             iv_buffer, target->key, keylen));

    COMPARE_ITEM(answ, target->p, inlen, false);

  }

  test_type = lea192_gcm_ae;
  keylen = 24;
  for (i = 0; i < sizeof(lea192_gcm_ae) / sizeof(LEA_GCM_AE); i++) {
    *target = test_type[i];
    inlen = target->p_len;

    memset(answ, 0, sizeof(answ));
    memcpy(iv_buffer, target->nonce, 16);

    TEST_ITEM(test_crypto_aead_encrypt(alg_name, true, answ, sizeof(answ), target->p,
                             inlen, target->assoc, target->assoc_len, iv_buffer, target->key, keylen));

    COMPARE_ITEM(answ, target->c, inlen, true);
    COMPARE_ITEM(answ + inlen, target->tag, 16, 2);

    memcpy(iv_buffer, target->nonce, 16);
    TEST_ITEM(test_crypto_aead_encrypt(alg_name, false, answ, sizeof(answ), answ, inlen + 16, target->assoc, target->assoc_len,
                             iv_buffer, target->key, keylen));

    COMPARE_ITEM(answ, target->p, inlen, false);
  }

  test_type = lea256_gcm_ae;
  keylen = 32;
  for (i = 0; i < sizeof(lea256_gcm_ae) / sizeof(LEA_GCM_AE); i++) {
    *target = test_type[i];
    inlen = target->p_len;

    memset(answ, 0, sizeof(answ));
    memcpy(iv_buffer, target->nonce, 16);

    TEST_ITEM(test_crypto_aead_encrypt(alg_name, true, answ, sizeof(answ), target->p,
                             inlen, target->assoc, target->assoc_len, iv_buffer, target->key, keylen));

    COMPARE_ITEM(answ, target->c, inlen, true);
    COMPARE_ITEM(answ + inlen, target->tag, 16, 2);

    memcpy(iv_buffer, target->nonce, 16);
    TEST_ITEM(test_crypto_aead_encrypt(alg_name, false, answ, sizeof(answ), answ, inlen + 16, target->assoc, target->assoc_len,
                             iv_buffer, target->key, keylen));

    COMPARE_ITEM(answ, target->p, inlen, false);
  }

fin:
  if (result == 0) {
    pr_info("LEA GCM AE : success\n");
  } else {
    pr_warn("LEA GCM AE : failed\n");
  }

  if (target != NULL) {
    kvfree(target);
  }

  return result;
}
