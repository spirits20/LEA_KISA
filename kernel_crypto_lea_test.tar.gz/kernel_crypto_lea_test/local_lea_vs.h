#ifndef LOCAL_LEA_VS_H
#define LOCAL_LEA_VS_H
typedef struct {
  unsigned char key[32];
  unsigned char p[160];
  unsigned char c[160];
} LEA_MMT_ECB;

typedef struct {
  unsigned char key[32];
  unsigned char iv[16];
  unsigned char p[160];
  unsigned char c[160];
} LEA_MMT_CBC, LEA_MMT_CTR;

typedef struct {
  unsigned char key[32];
  unsigned char nonce[16];
  unsigned char assoc[48];
  unsigned int assoc_len;
  unsigned char p[80];
  unsigned int p_len;
  unsigned char c[80];
  unsigned char tag[16];
} LEA_GCM_AE;

typedef struct {
  unsigned char key[32];
  unsigned char tweak_key[32];
  unsigned char tweak[16];
  unsigned char p[336];
  unsigned char c[336];
} LEA_MMT_XTS;

#endif