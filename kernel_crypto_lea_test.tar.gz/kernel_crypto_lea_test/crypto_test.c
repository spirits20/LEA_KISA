#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/time.h>

#include "crypto_test.h"

#define TIMEZONE_OFFSET (9 * 3600) // Asia/Seoul

#define TEST_ITEM(test) \
    do { \
      int res = test;\
      if(res != 0){\
        printk(KERN_ERR MODULE_PREFIX "FAILED %d\n", res);\
        return -EIO;\
      }\
    } while(0);

static void print_date(void) {
  struct timespec64 ts;
  struct tm tm;
  ktime_get_real_ts64(&ts);
  time64_to_tm(ts.tv_sec, TIMEZONE_OFFSET, &tm);
  pr_info(MODULE_PREFIX "Now = %02d-%02d-%02d %02d:%02d:%02d\n",
         (int)((tm.tm_year + 100l) % 100l), tm.tm_mon + 1, tm.tm_mday,
         tm.tm_hour, tm.tm_min, tm.tm_sec);
}

static int __init crypto_lea_test_init(void) {
  pr_info("Test Load!\n");
  print_date();
  TEST_ITEM(api_1block());
  TEST_ITEM(api_4block());
  TEST_ITEM(api_8block());
  TEST_ITEM(lea_mmt_ecb_test());
  TEST_ITEM(lea_mmt_cbc_test());
  TEST_ITEM(lea_mmt_ctr_test());
  TEST_ITEM(lea_mmt_xts_test());
  TEST_ITEM(lea_ae_gcm_test());

  printk(MODULE_PREFIX "Success!\n");

  return 0;
}

static void __exit crypto_lea_test_exit(void) {
  printk(MODULE_PREFIX "Unloaded!\n");
}

module_init(crypto_lea_test_init);
module_exit(crypto_lea_test_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Dongsoo Lee <letrhee@nsr.re.kr>");
MODULE_DESCRIPTION("LEA Cipher Algorithm Test Module");